import { NextRequest, NextResponse } from 'next/server';
import Parser from 'rss-parser';
import { createClient } from '@supabase/supabase-js';
import { RSSNewsItem } from '@/types';

// Cache results for 60 minutes
export const dynamic = "force-dynamic";
export const revalidate = 3600;

const parser = new Parser();

export async function GET(req: NextRequest) {
  try {
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        global: {
          headers: {
            Authorization: req.headers.get('Authorization') || '',
          },
        },
      }
    );

    // 1. Fetch active feeds and settings
    const [{ data: feeds }, { data: settings }] = await Promise.all([
      supabase.from('rss_feeds').select('*').eq('is_active', true),
      supabase.from('rss_settings').select('*').single(),
    ]);

    if (!feeds) {
      return NextResponse.json({ items: [] });
    }

    const priorityKeywords = settings?.priority_keywords || ['Tasas de cambio', 'CUP', 'Divisas', 'Política Monetaria'];

    // 2. Fetch and parse feeds
    const feedPromises = feeds.map(async (feed) => {
      try {
        const parsedFeed = await parser.parseURL(feed.url);
        return parsedFeed.items.map((item) => ({
          ...item,
          feedName: feed.name || parsedFeed.title,
        }));
      } catch (err) {
        console.error(`Error parsing feed ${feed.url}:`, err);
        return [];
      }
    });

    const allItems = (await Promise.all(feedPromises)).flat();

    // 3. Process items
    const processedItems: RSSNewsItem[] = allItems.map((item: any) => {
      const title = item.title || 'Sin título';
      const content = item.content || item.description || '';
      const contentSnippet = item.contentSnippet || content.substring(0, 200);
      const link = item.link || '';
      const pubDate = item.pubDate || item.isoDate || new Date().toISOString();

      // Priority check
      const isPriority = priorityKeywords.some((keyword: string) =>
        title.toLowerCase().includes(keyword.toLowerCase()) ||
        content.toLowerCase().includes(keyword.toLowerCase())
      );

      // Exchange rate detection (specific for BCC)
      let isExchangeRate = false;
      let exchangeRateData = undefined;

      if (item.feedName?.includes('Banco Central') || link.includes('bc.gob.cu')) {
        if (title.toLowerCase().includes('tasas de cambio') || title.toLowerCase().includes('tipo de cambio')) {
          isExchangeRate = true;
          // Pattern matching for Cuba BCC
          // Example: USD - 120.00, EUR - 130.00
          const usdMatch = content.match(/USD\s*-\s*([\d.]+)/i) || title.match(/USD\s*-\s*([\d.]+)/i);
          if (usdMatch) {
            exchangeRateData = {
              currency: 'USD',
              value: parseFloat(usdMatch[1]),
              date: pubDate,
            };
          }
        }
      }

      return {
        id: item.guid || item.id || link || Math.random().toString(36).substring(7),
        title,
        link,
        pubDate,
        content,
        contentSnippet,
        feedName: item.feedName,
        isPriority: isPriority || isExchangeRate,
        isExchangeRate,
        exchangeRateData,
      };
    });

    // 4. Sort: Priority first, then by date
    const sortedItems = processedItems.sort((a, b) => {
      if (a.isPriority && !b.isPriority) return -1;
      if (!a.isPriority && b.isPriority) return 1;
      return new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime();
    });

    return NextResponse.json({ items: sortedItems });
  } catch (err: any) {
    console.error('RSS API Error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
